
#define B_F   PIND0
#define B_B   PIND1
#define B_R   PIND2
#define B_L   PIND3

// void CAR_Init()
// {
	/* DO Nothing*/
	
/*}*/


//  void CAR_Runnable(void)
// {
// 	if (DIO_ReadPin(B_F)==LOW)
// 	{
// 		MoveForward();
// 	}
// }
// 
// static void MoveForward(void)
// {
// 	MOTOR_CW()
// }
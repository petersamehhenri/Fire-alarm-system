/** Interrupt ISR for INT0**/
void EX_INT0_Func(void)
{
	
}

void EX_INT1_Func(void)
{
	
}

void EX_INT2_Func(void)
{
	
}


#ifndef SENSORS_CFG_H_
#define SENSORS_CFG_H_

#define POT_CH		CH_0
#define LM35_CH		CH_7
#define MPX_CH		CH_0



#endif /* SENSORS_CFG_H_ */
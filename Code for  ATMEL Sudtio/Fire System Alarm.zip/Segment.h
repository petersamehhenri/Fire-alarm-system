

#ifndef SEGMENT_H_
#define SEGMENT_H_


void segment_display(unsigned char num);
void segment_display_Hex(unsigned char num);
void segment_display_BCD(int num);
void segment_display_kit(int num);



#endif /* SEGMENT_H_ */
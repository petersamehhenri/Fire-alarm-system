

#ifndef SERVO_H_
#define SERVO_H_

void SERVO_Init(void);


void SERVO_SetAngle(u8 angle);

#endif /* SERVO_H_ */